/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zumo;

/**
 *
 * @author elisa
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Zumo unDeposito;
        int relleno;
        /*Creación de un depósito con zumo de pomelo, inicialmente contiene 20 litros, su capacidad máxima es de 40,
       el precio del litro es de 2€*/
        unDeposito = new Zumo(20, 2, "Pomelo", 40);

        try {
            System.out.println("Vamos a tomar zumo");
            unDeposito.sacarZumo(5, 20); //Se intentan comprar 5 litros de zumo con un billete de 20€

        } catch (Exception e) {
            System.out.print("Error al sacar el zumo");

        }

        try {
            System.out.println("Rellenando depósito");
            unDeposito.rellenar(30); //Se intenta rellenar 30 lítros la capacidad máxima

        } catch (Exception e) {
            System.out.print("Error al rellenar el depósito");

            relleno = unDeposito.obtenerLitros();
            System.out.println("El depósito contiene" + relleno + "Litros");

        }
    }
}
